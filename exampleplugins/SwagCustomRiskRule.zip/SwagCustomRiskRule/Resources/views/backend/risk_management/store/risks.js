
//{block name="backend/risk_management/store/risk/data"}
// {$smarty.block.parent}
{ description: '{s name=risks_store/comboBox/myCustomRule}My custom rule{/s}', value: 'MyCustomRule' },
//{/block}
